Skylar Soon ONID: 934435873

Greetings Kenneth Tang! (please say i got it right)

Description: 
The first part of the assignment, recur.cpp, prints a diamond shape based on user input. The diamond size is based on the middle row. The first user input specifies how many rows down the middle row should be, and the second user input specifies how many leading spaces should be before the middle row on the left. It then generates a diamond recursively. 
The second part of the assignment  creates a standard linked list with nodes. I created functions to edit and view certain parts of the list. I did not complete sort_ascending and sort_descending as I ran out of time and must study for other things (sorry). I spent a lot of time trying to implement merge sort as you could see in the comments but I couldn't figure it out in time. 

Instructions: 
You can compile recur.cpp by typing 'g++ recur.cpp -o recur' in your terminal, then type ./recur to run it.

You can compile the linked list program by typing 'make'. Then type ./run in your terminal to run the linked list test.

Limitations: 
As I mentioned before I did not complete the merge sort so linked_list lacks sorting functionalities. My linked list program also has memory errors and leaks. 
Sorry I couldn't spend more time on this assignment. 
But thank you for all your time as a TA helping us! I really appreciate it whoever you may be.

Once again, thank you and have a great summer :)
