#include "bats.h"


char Bats::get_symbol(){
	return 'B'; 
}

void Bats::print_percept(){
	cout << "You hear wings flapping." << endl;
}