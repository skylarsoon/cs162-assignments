#include "pit.h"

char Pit::get_symbol(){
	return 'O'; 
}

void Pit::print_percept(){
	cout << "You feel a breeze." << endl;
}