#include "wumpus.h"

char Wumpus::get_symbol(){
	return 'W'; 
}

void Wumpus::print_percept(){
	cout << "You smell a terrible stench." << endl;
}

