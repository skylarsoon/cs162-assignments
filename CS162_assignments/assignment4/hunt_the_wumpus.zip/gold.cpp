#include "gold.h"

char Gold::get_symbol(){
	return '$'; 
}

void Gold::print_percept(){
	cout << "You see a glimmer nearby." << endl;
}